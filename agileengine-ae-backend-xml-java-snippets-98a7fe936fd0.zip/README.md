# AgileEngine backend-XML java snippets

It is built on top of [Jsoup](https://jsoup.org/).

You can use Jsoup for your solution or apply any other convenient library. 
